#!/usr/bin/env python
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import socket

class GestureControlNode(Node):
    def __init__(self):
        super().__init__('gesture_control_node')
        self.publisher_ = self.create_publisher(String, '/robot_control', 10)
        
        # 创建一个UDP Socket来监听指令 Create a UDP Socket to listen for commands
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("", 9090))  # 监听端口，等待主机发来的指令 Listen to the port and wait for instructions from the host
        self.get_logger().info("Gesture Control Node is up and waiting for commands")

        # 设置一个定时器，定期检查是否有新的指令到达 Set a timer to periodically check if any new instructions arrive
        self.timer = self.create_timer(0.1, self.receive_command)

    def receive_command(self):
        try:
            # 尝试接收数据，设定超时为0.1秒 Try to receive data, set the timeout to 0.1 seconds
            self.sock.settimeout(0.1)
            data, _ = self.sock.recvfrom(1024)  # 接收数据 Receiving Data
            command = data.decode("utf-8")
            
            # 打印收到的命令，便于调试 Print received commands for easy debugging
            if command == "left":
                self.get_logger().info("Received command: Left Swipe (左挥手)")
            elif command == "right":
                self.get_logger().info("Received command: Right Swipe (右挥手)")
            elif command == "stop":
                self.get_logger().info("Received command: Fist (握拳)")
            elif command == "start":
                self.get_logger().info("Received command: Open Hand (打开手掌)")
            else:
                self.get_logger().info(f"Received unknown command: {command}")

            # 将收到的命令封装成ROS消息并发布到话题 Encapsulate the received command into a ROS message and publish it to the topic
            msg = String()
            msg.data = command
            self.publisher_.publish(msg)  # 发布指令到ROS话题 Publish commands to ROS topics
            
        except socket.timeout:
            # 如果没有数据到达，跳过（不打印错误） If no data arrives, skip (do not print error)
            pass
        except Exception as e:
            self.get_logger().error(f"Error receiving command: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = GestureControlNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
